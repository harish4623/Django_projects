from django.shortcuts import render
import pickle
import numpy as np
from .models import Prediction  

# Loading the models and preprocessing objects
try:
    with open('random_forest_model.pkl', 'rb') as rf_file:
        rf_model = pickle.load(rf_file)

    with open('scaler.pkl', 'rb') as scaler_file:
        scaler = pickle.load(scaler_file)

    with open('label_encoder.pkl', 'rb') as encoder_file:
        encoder = pickle.load(encoder_file)

except Exception as e:
    # Handling error
    print(f"Error loading models or preprocessing objects: {e}")
    rf_model, scaler, encoder = None, None, None  

def home(request):
    return render(request, 'home.html')  

def index(request):
    return render(request, 'index.html')  

def predict(request):
    if request.method == 'POST':
        print("Received POST request")  
        
        # Getting input features from the form
        try:
            features = [
                float(request.POST['mcg']),
                float(request.POST['gvh']),
                float(request.POST['alm']),
                float(request.POST['mit']),
                float(request.POST['erl']),
                float(request.POST['pox']),
                float(request.POST['vac']),
                float(request.POST['nuc']),
            ]
        except KeyError as e:
            print(f"Missing feature in form data: {e}")
            return render(request, 'index.html', {'error': 'Please provide all required fields.'})

        # Scaling the features
        features_scaled = scaler.transform([features])

        # Making predictions
        rf_prediction = rf_model.predict(features_scaled)

        # Decoding predictions to class names
        rf_predicted_class = encoder.inverse_transform(rf_prediction)[0]

        # Saving predictions to the database
        prediction_record = Prediction(
            mcg=features[0],
            gvh=features[1],
            alm=features[2],
            mit=features[3],
            erl=features[4],
            pox=features[5],
            vac=features[6],
            nuc=features[7],
            Name=rf_predicted_class  
        )
        prediction_record.save()  # Saving the output to database

        all_predictions = Prediction.objects.all()  

        return render(request, 'prediction.html', {
            'Name': rf_predicted_class,  
            'all_predictions': all_predictions  
        })

    return render(request, 'index.html')
