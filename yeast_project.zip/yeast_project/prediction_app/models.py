from django.db import models

class Prediction(models.Model):
    mcg = models.FloatField()
    gvh = models.FloatField()
    alm = models.FloatField()
    mit = models.FloatField()
    erl = models.FloatField()
    pox = models.FloatField()
    vac = models.FloatField()
    nuc = models.FloatField()
    Name = models.CharField(max_length=100)  

    def __str__(self):
        return f'Prediction - Name: {self.name}'
